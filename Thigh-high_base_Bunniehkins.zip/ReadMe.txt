Downloaded from: http://www.furaffinity.net/view/24373257/
----

It's been a while hasn't it? :) But I've finally made another base!

Consider this as a thankyou for all your support in me and my artwork! ^.^ (only have one version this time, sorry!)

A few little rules first of all:

- You may edit the base however you like
- You may use this base for YCH's etc and make money from it
- Do not sell on the blank file as being your own
- Always credit me when you use this base

Have fun! feel free to link anything you make with this in the comments~ I'd love to see ^.^

----
You can find me at my website, on FurAffinity, or Twitter:

http://www.bunniehkins.com/
http://www.furaffinity.net/user/bunniehkins/
https://www.twitter.com/bunniehkins/
----
